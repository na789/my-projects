const express = require('express');
 const path = require('path');
const port = 8000;
const db=require('./config/mongoose');

const Task = require('./models/dotask');

//using express server
const app = express();

app.set ('view engine','ejs');
app.set ('views', path.join(__dirname ,'views'));
app.use(express.urlencoded());
app.use(express.static('assets'));

//static array list
const todolist =[
    {
        task:"complete assignment",
        date:"12/02/2020",
        type_task:"task"
    }]

app.get('/' , function(err , res){

    Task.find({},function(err,todolist){
        if(err){
            console.log('error in fetching a task from db');
            return;
          }
          return res.render('home',{
            title:"to do list",
            todo_list:todolist
         });
    });
   
    });
// app.get('/' , function(req , res){
//     return res.render('home',{
//         title:"to do list",
//         todo_list:todolist
//     });
//  });


 app.post('/create_task' , function(req , res){

    // todolist.push(req.body);
    // return res.redirect('back');

    Task.create({
        task:req.body.task,
        date:req.body.date,
        type_task:req.body.type_task
    },function(err,newTask){
      if(err){
        console.log('error in adding a task');
        return;
      }
    console.log('********',newTask);
    return res.redirect('/');
    });
});

//delete a task

// app.get('/delete_task',function(req,res){

//     var date= req.query.checkbox;
//     console.log(date);
    
//      let taskIndex = todolist.findIndex(todo => todo.date == date);
//     console.log(taskIndex);
//     if(taskIndex !=-1)
//     {
//         todolist.splice(taskIndex,1);
//     }
//     return res.redirect('back');
// });
//deteling a contact

app.get('/delete_task/',function(req,res){
    //get id from query in url
     let id=req.query.id;
     
      //finding task using id from the db and delete
      Task.deleteOne(id , function(err){
          if(err){
              console.log('error in deleting an object from db');
              return;
          }
          return res.redirect('back');
      });
            
      
 });
//checking express server is up or not

app.listen(port , function(err){
    if(err){
        console.log('error in running the server' , err);
    }

    console.log('yup ! my express server is running on port :', port);
});
