//require the library
const mongoose = require('mongoose');
//connect to the db
mongoose.connect('mongodb://localhost/todo_list_db');
//acquire the connection(to check if successful)
const db =mongoose.connection;
//if error then print this
db.on('error' , console.error.bind(console , 'error connecting to db'));
//if no error then print this
db.once('open' ,function(){
    console.log('successfully connected to the database');
});
