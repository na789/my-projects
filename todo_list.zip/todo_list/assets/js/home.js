var categorybtn =document.getElementsByClassName('category');
for(var  i=0; i< categorybtn.length ;i++)
{

    categorybtn[i].addEventListener('click',function (){
	var val=this.getAttribute('value');
	list.input.innerText +=val;

});
}